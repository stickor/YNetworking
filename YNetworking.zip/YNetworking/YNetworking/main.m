//
//  main.m
//  YNetworking
//
//  Created by 杨引 on 2018/9/28.
//  Copyright © 2018 Y. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
